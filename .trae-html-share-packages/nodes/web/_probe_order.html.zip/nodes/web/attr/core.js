// ==================== 图层 Attribute ====================
// 图层不再自带蒙版 / 贴片 / 特效链:它持有**一串有序 guid** (`l.attrs`),数据住在文档级的
// `attrRecords` 表里。这张表存在的理由只有一条 —— Attribute 要能被拖拽排序、能被复制成引用,而这两件
// 事都要求"一个 attribute 是一个数得出来的对象",不是图层上的三个字段。
//
// 四条规矩:
//   · **应用顺序 = 数组顺序,从左到右**。注册表里的 `order` 只管新建那一瞬间的默认落点
//     (decal → effects → mask,也就是这个功能出现之前那条固定管线的顺序);建好之后顺序归用户拖,
//     表里再没有第二个"顺序"。
//   · 同一种可以装多个 (多张 Mask 互相叠、多个 Effects 容器各管它右边那一段链)。图层上那三个老名字
//     (`l.mask` / `l.decal` / `l.effects`) 是**最左边那一个**的视图 —— 迁移、快照、剪贴板那一类调用
//     先不必理解 strip;会同时存在好几枚的那两样 (落笔、链 UI) 一律**点名**到哪一枚 (paintRecord /
//     chainOwnerRecord),否则"这一步的哪一条链"就没有唯一答案。真正的折叠在引擎里按整串走。
//   · **有 attribute 才有数据**:装上一个空的 Mask 就是"蒙版还没画",跟没装等价,所以迁移只在字段真
//     有内容时才立记录。反过来 `l.mask = null` 是把这一枚摘掉,而不是留着它装空。
//   · refs 一律**扫**出来,不落字段;快照与档存值 + 它自己的 guid (guid 就是身份,重放照号收下,所以
//     特效指向 attribute 的引用活得过重开),表因此永远不必替历史保管任何东西。
//
// 文件切分跟 fx 一样:本文件只装"strip 的模型"(注册表容器 + 引用计数 + 迁移 + 快照/克隆)。每一种
// attribute 自己一个 attr/<type>.js,里面齐活注册数据 (标签、默认落点、老字段名) 与 S4 要的缩略图;
// 加一类 = 写一个文件 + 在页面里加一行 <script src>。两三种 attribute 共用的那套算法 (面 / 链) 按
// `kind` 放在 ATTR_KINDS 里,谁想换掉就在自己的 spec 里写同名函数。

const ATTR_TYPES = {};

// 旧 **type 名** → 现在的名字。P0 把 decal 改名 image：档里存的、撤销快照里留的都还是 'decal'，
// 一律在读端改名，写出去只有 'image'。**少了这一层，旧档的贴片会被 `ATTR_TYPES[...]` 认不出，
// 在 adoptAttrPayloads / recAttrEntries 里被静默丢掉** —— 症状是旧档打开后所有笔画不见。
// 注意它和老**字段**名 (`spec.legacy = 'decal'` → `l.decal`) 是两件事:一个改类型,一个改属性。
const ATTR_TYPE_ALIAS = { decal: 'image' };
function canonAttrType(t) { return ATTR_TYPE_ALIAS[t] || t; }

function defineAttrType(spec) {
    if (!spec || !spec.type || !ATTR_KINDS[spec.kind] || ATTR_TYPES[spec.type]) {
        throw new Error('bad attribute definition: ' + String(spec && spec.type));
    }
    const kind = ATTR_KINDS[spec.kind];
    // 没自带的算法从 kind 那里拿 —— spec 只写它跟兄弟不一样的那部分。
    for (const fn of ['init', 'fromLegacy', 'snap', 'load', 'clone', 'chip', 'open']) {
        if (!spec[fn]) spec[fn] = kind[fn];
    }
    ATTR_TYPES[spec.type] = spec;
}

// 两种数据形状:一张画得出的**面** (蒙版、贴片),和一条**链** (特效)。同一个 kind 里的类型除了落点
// 与标签之外没有第二种规矩。
const ATTR_KINDS = {
    surface: {
        // frameTrack = 这一枚面在视频模式下改从**哪条视频轨的当前帧**取 ('' = 就用画好的这张)。
        // 它是记录自己的财富,所以跟面一起进快照/存档/复制 —— 读不到轨道时按"没有帧"处理,不改这张面。
        init: () => ({ surface: null, frameTrack: '' }),
        // 老字段有面才立记录 (见上面"有 attribute 才有数据")。
        fromLegacy: raw => (raw ? { surface: raw } : null),
        snap: r => {
            const s = r.frameTrack ? { surface: r.surface, frameTrack: r.frameTrack } : { surface: r.surface };
            // 底位是**身份**:那一枚是"这一层自己的像素"而不是一步,快照丢了这一格,undo 回来就
            // 变成"底位 + 一张全幅贴片"两张图叠着 (不透明图看不出,带 alpha 的图当场变浓)。
            if (r.role) s.role = r.role;
            if (r.src) s.src = r.src;
            return s;
        },
        load: raw => {
            const r = { surface: raw.surface || null, frameTrack: typeof raw.frameTrack === 'string' ? raw.frameTrack : '' };
            if (raw.role) r.role = raw.role;
            if (raw.src) r.src = raw.src;
            return r;
        },
        clone: (r, dup) => {
            const c = { surface: dup(r.surface), frameTrack: r.frameTrack || '' };
            if (r.role) c.role = r.role;
            if (r.src) c.src = r.src;
            return c;
        },
        // chip = 条带上那颗缩略图。它只负责**画**,节点本身由 blend_node 的那颗 chip 造好交进来 ——
        // 因为"有没有这颗 chip"归条带管,"这颗 chip 上摆什么"才归 attribute 管。
        // 蒙版与贴片画的是同一件事 (把自己那张面按图层网格的比例摆进这块小画布),规矩只有一处不同:
        // 贴片留空 (CSS 的棋盘格透出 = 没画),蒙版得自己填底色 —— 说在各自 spec 的 `chipBg` 里。
        // 点这颗 chip = 把笔落到**这一枚**上 (不是"最左那枚",也不是"这一种")。
        open(l, r) { setPaintTarget(r.type, l, r.id); },
        chip(el, r, l) {
            const w = el.width, h = el.height, c = el.getContext('2d');
            resetCtx(c);
            // 先清空再画:擦皮 (destination-out) 只削面自己的 alpha,重画是"叠"不是"换" —— 不清
            // 的话擦掉的部分在 chip 上永远是旧墨。蒙版看不出来是因为它每帧都铺满 chipBg 底色,
            // 恰好盖住上一帧;贴片没有底色,吃的就是这个亏。
            c.clearRect(0, 0, w, h);
            const bg = ATTR_TYPES[r.type].chipBg;
            const fill = typeof bg === 'function' ? bg(r) : bg;
            if (fill) { c.fillStyle = fill; c.fillRect(0, 0, w, h); }
            const s = r.surface;
            if (!s || !s.width || !s.height) return;
            const src = nativeSize(l.img);
            if (!src.w || !src.h) return;
            const k = Math.min(w / src.w, h / src.h);
            const dw = src.w * k, dh = src.h * k;
            c.drawImage(s, (w - dw) / 2, (h - dh) / 2, dw, dh);
        },
    },
    chain: {
        init: () => ({ chain: [] }),
        fromLegacy: raw => (Array.isArray(raw) && raw.length ? { chain: raw } : null),
        // 链是可变结构 (改参数就改数组里那个对象),所以进快照的必须是深拷贝。
        snap: r => ({ chain: cloneEffects(r.chain) }),
        // 读快照同样拷一份:参数会就地改,直接把历史里那条数组交给活图层,下一次编辑就把它改掉,
        // undo 便回不到当初那一步。面 (canvas) 不必 —— 它是 copy-on-write 的。
        load: raw => ({ chain: cloneEffects(raw.chain) }),
        clone: r => ({ chain: cloneEffects(r.chain) }),
        // 链没有面可画,所以这条 chip 是一枚**魔棒** —— 它是"顺序里有这么一步"的记号,不是内容预览。
        chip(el) {
            if (el.dataset.icon !== 'chain') { el.innerHTML = fxWandSvg(); el.dataset.icon = 'chain'; }
        },
        // chip 上那根魔棒 = 这条链的**添加**入口 (行头上那颗已经搬走了 —— 一个动作一个入口)。
        // 它开的是**这一枚**记录的选择器:同一种挂了两枚容器时,选中的那个容器收下这一步。
        open(l, r) { openFxModal(l.id, r.id); },
    },

    // 第三种数据形状:**生成器**。描述符在档,面是派生 —— 描述符 (不可变,patch 一律整只换) 与
    // 盒子在档,像素由 spec.sync 惰性重算 (键比对,换新画布从不就地重画,undo 安全)。文字、方向、
    // 3D 烘焙都是这一种:`ownsGrid` 的那批 (老文字/方向/3D 层迁来的) 连图层格子都归它管 —— 格子
    // 跟着 transform 盒子走,底换成透明画布,面才是内容;不 ownsGrid 的那批 (挂在照片层上的) 面
    // 按图层网格现算,box 说明它占格子的哪一块。
    generator: {
        init: () => ({ desc: null, surface: null, genCache: null }),
        // 描述符按引用进快照 (不可变,与 cud 描述符同一条规矩);面不进 —— 它是派生数据,sync 会
        // 重算。3D 例外:bake 出来的面算不回来,由它自己的 spec 覆盖 snap 把面带上。
        snap: r => ({ desc: r.desc, box: r.box || null, ownsGrid: !!r.ownsGrid, sceneUid: r.sceneUid || null }),
        load: raw => ({ desc: raw.desc, box: raw.box || null, ownsGrid: !!raw.ownsGrid, sceneUid: raw.sceneUid || null }),
        // desc 按引用共享 (不可变);sceneUid 同理 —— 副本与原本跳进同一个场景。面不带:sync 自己算。
        clone: r => ({ desc: r.desc, box: r.box || null, ownsGrid: !!r.ownsGrid, sceneUid: r.sceneUid || null }),
        // chip 画的就是那张派生面 (它本来就是图层网格的形状,拉满即可);还没算出来时留空 ——
        // 空不等于停用,停用有角标说话。
        chip(el, r) {
            const c = el.getContext('2d');
            resetCtx(c);
            if (r.surface && r.surface.width && r.surface.height) c.drawImage(r.surface, 0, 0, el.width, el.height);
        },
    },
};

let attrSeq = 0;
// 一次页面加载一个盐。新号必须**永远不可能等于一份档里带来的号**:老文件的号是纯数字 (`attr_4`),
// 而这一枚盐保证盐里至少有一个字母、新号 therefore 从不长得像老号 —— 读档那一步 (adoptAttrPayloads)
// 是照档里的号收下记录的,撞号就等于把人家那枚记录顶掉、图层还指着那个键。
const attrSalt = 'a' + Math.random().toString(36).slice(2, 7);
const attrRecords = new Map();          // guid -> { id, type, ...payload } (guid 就是这一枚 attribute 的身份)

// `guid` 只由读档那一步交进来 (照档里的号收下);新立的 (装上来、复制、粘贴) 一律现 mint。
function newAttrRecord(type, fields, guid) {
    const spec = ATTR_TYPES[type];
    if (!spec) return null;
    // enabled = 这一步参不参与折叠。缺席读作 true (见 attrEnabled),所以快照里只有 false 才落字段。
    const r = Object.assign({ id: (typeof guid === 'string' && guid) || ('attr_' + attrSalt + (++attrSeq)),
        type, enabled: true }, spec.init(), fields || {});
    attrRecords.set(r.id, r);
    return r;
}

function attrRefList(l) { return l && Array.isArray(l.attrs) ? l.attrs : []; }
// 按 strip 顺序拿到记录;认不出的 guid (表里已经被 prune 掉) 直接跳过,绝不让一个悬空引用把整串挡住。
function attrRecordsOf(l) {
    const out = [];
    for (const ref of attrRefList(l)) {
        const r = attrRecords.get(ref);
        if (r && ATTR_TYPES[r.type]) out.push(r);
    }
    return out;
}
// **底位**(`role:'base'`) 是"这一层自己的像素"那一枚 image —— 但它**也是条带上普通的一步**:
// 位置随便放,顺序就是生效顺序,拖到一条链右边 = 那条链在画它之前跑(于是这条链不作用于它)。
// 只有"这一种 attribute 是哪一枚"那类查询(`l.decal`、链路 UI)跳过它 —— 那些问的是"额外那一枚",
// 落到自己身上没有意义。
function isBaseAttr(r) { return !!r && r.role === 'base'; }
function findAttr(l, type) {
    for (const r of attrRecordsOf(l)) if (r.type === type && !isBaseAttr(r)) return r;
    return null;
}
// 同一种装了多枚时,**最右**那枚是"这个图层自己那一步的最后一次"。落笔的快捷键点的是它:画笔要落在
// 执行序末尾那一刀上,而不是落在最早那一枚上 (老语义里只有一枚,两种读法没有区别)。
function lastAttr(l, type) {
    let hit = null;
    for (const r of attrRecordsOf(l)) if (r.type === type && !isBaseAttr(r)) hit = r;
    return hit;
}
function attrRecord(ref) { return ref ? attrRecords.get(ref) || null : null; }
// 有没有特效**引用**这一枚记录 (params 里存着它的 guid,如 Lighting 的 dirRef)。引用的形式只有一种
// —— 字符串参数恰是记录的 guid —— 所以按值扫一遍就覆盖了现有与将来的所有绑定,新依赖不必来注册。
// 只扫活图层:跨文档的绑定在对方文档激活时才落地成活链,那时自然扫得到。
function attrHasEffectRef(r) {
    if (!r || typeof layers === 'undefined') return false;
    for (const l of layers) {
        if (l.isMaskLayer) continue;
        for (const rec of attrRecordsOf(l)) {
            if (!rec.chain) continue;
            for (const e of rec.chain) {
                if (!e || !e.params) continue;
                for (const k in e.params) {
                    if (e.params[k] === r.id) return true;
                }
            }
        }
    }
    return false;
}
// 停用的一步 = 数据原地留着,折叠跳过它 (fx/gl.js 的 fxDropStrip 与 attrInks 都认这一句)。
// 缺席也算开:老快照、克隆路上没带这个字段的记录不会被误停。
function attrEnabled(r) { return !r || r.enabled !== false; }
// 条带上**全部**链,按应用顺序。老名字 `l.effects` 只是最左边那一枚的视图,所以缓存签名、贴图戳这类
// 「整层重算不算」的判据一律读这一串 —— 只看最左那一条会漏掉右边那枚容器。
function stripChains(l) {
    return attrRecordsOf(l).filter(r => r.chain).map(r => r.chain);
}
// 从**特效 id** 出发的读法一律走这一句:一枚 id 住在某一条链里,而那条链属于哪一枚 Effects 记录不是
// 图层能凭老名字答的 (`l.effects` 只看最左那枚)。右边那枚容器里的一步 warp / 一次绑图,查不到就
// 什么都不会发生 —— 静默失败比报错更难查。
function chainOwnerRecord(l, effectId) {
    for (const r of attrRecordsOf(l)) {
        if (r.chain && r.chain.some(e => e && e.id === effectId)) return r;
    }
    return null;
}
function effectById(l, effectId) {
    const r = chainOwnerRecord(l, effectId);
    return r ? r.chain.find(e => e && e.id === effectId) : null;
}
// 整条条带上"还挂着、且开着"的特效 (停用的容器整枚不算)。状态文案与"这层到底有没有链"那一类读数
// 都该问这一句:问最左边那一枚容器会漏掉右边那枚,而那句话说的正是这一层。
function liveEffects(l) {
    const out = [];
    for (const r of attrRecordsOf(l)) {
        if (!r.chain || !attrEnabled(r)) continue;
        for (const e of r.chain) if (e && e.enabled) out.push(e);
    }
    return out;
}

// ---- 生成器的惰性同步 ----
// 面是派生的,所以在**折叠之前**每一枚 generator 记录都要过一遍 spec.sync:键没变就两下比对比过去了,
// 变了才重算。折叠的三个入口 (fxResolved / fxSplitForBackend / fxSurfaceForGenerate) 开头都喊这一句
// —— fxResolved 的早退判据 (attrInks) 读的是面,同步必须发生在它**之前**,否则一枚还没算过面的
// 文字记录会被当成"没装"。
function syncGeneratorFaces(l) {
    if (!l || l.isMaskLayer) return;
    for (const r of attrRecordsOf(l)) {
        const spec = ATTR_TYPES[r.type];
        if (spec.kind === 'generator' && spec.sync && attrEnabled(r)) spec.sync(l, r);
    }
}
// 条带上"会出图的生成器":Generate 通道那句「这层到底有没有墨」问的是它 —— 空文字、停用的步骤
// 都不算。每类生成器自己报一句 (spec.ink),注册表不认得具体类型。
function stripGeneratorInk(l) {
    for (const r of attrRecordsOf(l)) {
        if (!attrEnabled(r)) continue;
        const spec = ATTR_TYPES[r.type];
        if (spec.kind === 'generator' && spec.ink && spec.ink(r)) return true;
    }
    return false;
}

function attrRefs(ref) {
    if (!ref) return 0;
    let n = 0;
    for (const l of layers) if (attrRefList(l).indexOf(ref) >= 0) n++;
    // Video 的每个 Layer 段各有一套图层（见 blend_node.html 的 layerSets），它们也拿这张表当视图：
    // 不算上，"换文档"那趟 pruneAttrs 会把正在等着的那些段里的记录当场放手（文字描述符、特效链全没）。
    // 活跃那套就是上面的 layers，别数两遍。
    for (const [key, s] of layerSets) {
        if (key === activeLayerSet) continue;
        for (const l of (s.layers || [])) if (attrRefList(l).indexOf(ref) >= 0) n++;
    }
    // 剪贴板是表外的持有者 (复制之后把原本删掉,再粘贴必须还有那份数据可贴),所以它也算一次引用。
    const cb = clipboardRecord && clipboardRecord.layer;
    if (cb && attrRefList(cb).indexOf(ref) >= 0) n++;
    // 那张纯 Mask 层不在 `layers` 里,但它也是一个活的持有者 (它的底位与它自己的步骤都住在这张表)。
    // 不算上,"删掉最后一层"那趟 pruneAttrs 会当场放掉 Mask 的画布。
    if (maskLayer && maskLayer !== cb && attrRefList(maskLayer).indexOf(ref) >= 0) n++;
    return n;
}

// 新建时的落点。`at` 说的是"跟谁相邻",不是绝对下标 —— 用户拖过的顺序不能被一次新增打乱。
function attrInsertIndex(l, type) {
    const at = ATTR_TYPES[type].at;
    const refs = attrRefList(l);
    if (at.rel === 'head') return 0;
    if (at.rel === 'tail') return refs.length;
    let anchor = -1;
    for (let i = 0; i < refs.length; i++) {
        const r = attrRecords.get(refs[i]);
        if (r && r.type === at.of) { anchor = i; break; }
    }
    if (anchor < 0) return refs.length;
    return at.rel === 'before' ? anchor : anchor + 1;
}

// `where` 是调用方点名的落点,盖过注册表里的默认 (`'tail'` = `+` 菜单的那句"加在最后一步")。没有它才
// 走 `at` 的策略 —— 那套策略只为迁移与老入口存在,用户自己排的顺序不能被一次新增打乱,更不能被"种类"打断。
function insertAttr(l, type, where) {
    const r = newAttrRecord(type);
    if (!r) return null;
    if (!Array.isArray(l.attrs)) l.attrs = [];
    const i = where === 'tail' ? l.attrs.length : attrInsertIndex(l, type);
    l.attrs.splice(i, 0, r.id);
    return r;
}

// chip 右键的 Shallow Duplicate:另立一枚同类型的记录,排在原本那枚**右边** (在它之后生效)。
// 面**另起一张**,像素照抄当下 —— 共享一面在这条路上活不过第一笔: detachPaintSurface 在落笔之前就把
// 这一层的面换成私有副本,对面那枚仍指着旧画布,于是"两枚永远同步"只成立到第一次作画为止。与其让一
// 个看不见的引用在两笔之间悄悄变了名分,不如 duplicate 那一刻就各拿一张面。链同理:effect 对象是就地
// 改参数的,所以带过来的也是它自己的一份。
function dupAttrShallow(l, ref) {
    const src = attrRecord(ref);
    if (!src || attrRefList(l).indexOf(ref) < 0) return null;
    const spec = ATTR_TYPES[src.type];
    // payload 一律问 spec.clone:面 (surface kind) 另起一张,链深拷,生成器带描述符不带走派生面
    // (sync 自己算),3D 把烘好的面 dup 一份 (它算不回来)。
    const copy = newAttrRecord(src.type, spec.clone(src, cloneCanvasSurface));
    if (!copy) return null;
    copy.enabled = attrEnabled(src);
    l.attrs.splice(attrRefList(l).indexOf(ref) + 1, 0, copy.id);
    return copy;
}

// 图层自己的网格变了 (换画布尺寸、rasterize、Expand、Fit Mask 裁边),条带上**每一枚面**都得跟着走:只搬
// 最左那一枚,右边那枚就留在旧尺寸上,合成时它被拉伸到新的格子里 —— 画面看着对,后端拿到的 mask 与 src
// 却是两个尺寸。fn 拿到面连同它所属的记录 (蒙版要在新空间补满覆盖,贴片不补 —— 分流是种类的知识),
// 交回新画布才替换 (没人改就不动身份)。
// 换的是**本层那一条引用**,不是那张面:这一枚还有别的持有者 (另一层、或剪贴板) 时,本层改握一枚新记录,
// 旧记录连它那张面原样留给对方 —— 裁自己的边不能顺着共享引用漏进别人的图层。同一层把一枚挂两次,两条
// 引用一起搬到同一枚新记录上,否则"乘两次"会在一次裁边之后散成两张各画各的面。
function remapAttrFaces(l, fn) {
    const refs = attrRefList(l);
    const done = new Map();               // 旧 guid -> 本层现在该握的那枚 guid (不换身份时就是它自己)
    for (let i = 0; i < refs.length; i++) {
        const r = attrRecord(refs[i]);
        if (!r || !r.surface) continue;
        // 底位不跟着"面"搬:它就是这一层的像素本身,由调用方自己的人那一步 (writeSource / 重采样)
        // 换掉。这里要是也搬一次,同一张图会被缩两遍。
        if (isBaseAttr(r)) continue;
        // 生成器的面是派生数据,不跟着格子搬:格子变了由 sync 按新网格现算 (3D 的 bake 折叠时
        // 自动拉伸)。搬它反而会把一张按旧网格算好的面钉在新格子上。
        if (ATTR_TYPES[r.type].kind === 'generator') continue;
        // 一枚挂两次 = 同一步走两遍,它只该被裁一遍:第二遍拿第一遍的结果再裁一次,边就缩了两回。
        if (done.has(r.id)) { refs[i] = done.get(r.id); continue; }
        const next = fn(r.surface, r);
        if (!next || next === r.surface) continue;
        const cb = clipboardRecord && clipboardRecord.layer !== l ? clipboardRecord.layer : null;
        const shared = layers.some(o => o !== l && attrRefList(o).indexOf(r.id) >= 0)
            || !!(cb && attrRefList(cb).indexOf(r.id) >= 0);
        if (shared) {
            const own = newAttrRecord(r.type, { surface: next, frameTrack: r.frameTrack || '' });
            refs[i] = own.id;
            done.set(r.id, own.id);
            markAttrPainted(own);
        } else {
            r.surface = next;
            done.set(r.id, r.id);
            markAttrPainted(r);
        }
    }
}

function removeAttr(l, ref) {
    const refs = attrRefList(l);
    const i = refs.indexOf(ref);
    if (i >= 0) refs.splice(i, 1);
    if (attrRefs(ref) === 0) attrRecords.delete(ref);
}

// ---- 两类数据的读写口 ----
// 同一种装了多枚时,老名字读写的都是**最左边那一个**:它对应这个功能出现之前唯一的那一枚。
function attrSurface(l, type) {
    const r = findAttr(l, type);
    return r ? r.surface : null;
}
function setAttrSurface(l, type, surface) {
    const spec = ATTR_TYPES[type];
    const r = findAttr(l, type);
    if (!surface) {
        if (r) removeAttr(l, r.id);
        return null;
    }
    (r || insertAttr(l, type)).surface = surface;
    return surface;
}
function attrSurfaceCtx(l, type) {
    const s = attrSurface(l, type);
    return s ? s.getContext('2d') : null;
}
function attrChain(l) {
    const r = findAttr(l, 'effects');
    return r ? r.chain : null;
}
// 交一个数组过来就是要一个容器 (哪怕空的):`l.effects = []` 读作"这条链清空,但容器留着"。
// 要摘掉容器得说 `l.effects = null`。
function setAttrChain(l, list) {
    if (!Array.isArray(list)) {
        const r = findAttr(l, 'effects');
        if (r) removeAttr(l, r.id);
        return null;
    }
    const r = findAttr(l, 'effects') || insertAttr(l, 'effects');
    r.chain = list;
    return list;
}

// ---- 记录身上的两笔账 ----
// · paintGen:面是**就地改写**的 (落笔在同一个 canvas 上画),身份不变,折叠缓存只看身份就看不见新墨。
//   图层那个 l.paintGen 只说图层自己的像素;共享面被 A 改一笔时 B 的缓存也必须脏,所以这一笔记在记录上。
// · 顺序归图层:拖完改的是图层的 `l.attrs`,不是记录 (见 moveAttr)。
// 缓存的落笔判据:每枚记录自己的代次,按条带顺序串成一个键。图层那个 paintGen 只说自己那份像素,
// 它盖不住"共享面被别的层改了一笔"这件事 —— 那必须是这一串里的某一格变了。
function attrPaintGens(l) {
    let s = '';
    for (const r of attrRecordsOf(l)) s += ':' + (r.paintGen | 0);
    return s;
}
function markAttrPainted(r) { if (r) r.paintGen = (r.paintGen | 0) + 1; }

// chip 的 ctrl+click 调这一句:翻转这一步的启用状态。翻转本身不改任何像素与数据 —— 面的身份、描述符、
// 链都原地不动,折叠缓存 (fxResolved) 却必须知道结果变了,所以代次 +1 就是这里唯一要干的"脏活"。
function toggleAttrEnabled(r) {
    if (!r) return;
    r.enabled = !attrEnabled(r);
    markAttrPainted(r);
    return r;
}

// chip 的 tooltip 要说清"这一枚是第几步",因为顺序现在归用户。只挂了一枚时不必报数 —— 那串括号
// 没有信息量,而条带上本来就只有一颗 chip 可读。
function attrStepNote(label, r, l) {
    const recs = attrRecordsOf(l);
    const i = recs.indexOf(r);
    return recs.length < 2 ? label : `${label} (step ${i + 1} of ${recs.length})`;
}

// 拖拽重排的那一份**缝位**算法:落在第 k 颗的哪一侧 = 插到它的位置,还是它后面。下标一律按**摘之前**
// 那个数组说,所以调用方不必知道自己会不会被摘掉 (摘掉之后它左边那道缝还是同一条)。两种排法
// (条带的横排、链的竖排)都是"数组序 = 执行序"。列表里存的不是 id 本身 (链存的是特效对象) 就交一个
// `idOf` 读出它的 id。落不到同一列表里 (拖的是被拖的那颗自己、或者目标根本不在这条里) 就回 -1,
// 一行都不动。
function listSlot(refs, dragId, targetId, after, idOf) {
    const key = idOf || (v => v);
    const from = refs.findIndex(v => key(v) === dragId);
    const to = refs.findIndex(v => key(v) === targetId);
    if (from < 0 || to < 0 || from === to) return -1;
    const at = to + (after ? 1 : 0);
    const [item] = refs.splice(from, 1);
    refs.splice(at > from ? at - 1 : at, 0, item);
    return refs.findIndex(v => key(v) === dragId);
}

// 拖拽重排:把 `dragRef` 插到同一条里 `targetRef` 那一颗的左边还是右边。缝位算法住在 `listSlot`。
//
// 这里**不再钳制底位**。从前底位必须恒在最左,于是"拖一枚 image 到最前"是不可能的 —— 也正是用户
// 报的那句"image attribute 拖不动"。现在底位跟别的步骤一样按落点走:位置就是生效位置(拖到一条 FX 链
// 右边,那条链就不作用于它)。`role:'base'` 由页面那一侧的 `ensureBaseInStrip` 归到 `l.srcRef` 说的
// 那一枚,不跟位置走。
function moveAttr(l, dragRef, targetRef, after) {
    const refs = attrRefList(l);
    return listSlot(refs, dragRef, targetRef, after) >= 0;
}

// 跨层移动:把 `ref` 从 `src` 的条带摘下来,插进 `dst` 的 `targetRef` 那一侧 (`targetRef` 为空 =
// 追加尾步,空条带的落点只有这一个读法)。记录本体不动 —— 表是文档级的,动的只有两条引用串;共享的
// 那枚被第三方照旧持有 (纯移动)。两笔跟着落点走:
//   · ownsGrid 的生成器离开老宿主就交还格子:清掉 ownsGrid,面由 spec.sync 按新层网格现算 (3D 没有
//     sync,烘面是唯一真相,原样带走);非 ownsGrid 的生成器也 sync 一遍 —— 键里带着格子尺寸,换了
//     层多半要重算,键没变就两下比对过去。
//   · 面 (mask/decal) 住的是图层空间,后端契约要求 mask 与 src 同格:落到尺寸不同的层上就重采样到
//     新网格。走 remapAttrFaces —— 共享的那枚在这里自然拆成落点层自己的新记录,原面留给原持有者。
function moveAttrToLayer(src, dst, ref, targetRef, after) {
    const rec = attrRecord(ref);
    const refs = attrRefList(src);
    if (!rec || !dst || src === dst || refs.indexOf(ref) < 0) return false;
    if (rec.ownsGrid) { rec.ownsGrid = false; markAttrPainted(rec); }
    refs.splice(refs.indexOf(ref), 1);
    if (!Array.isArray(dst.attrs)) dst.attrs = [];
    const to = targetRef ? dst.attrs.indexOf(targetRef) : dst.attrs.length;
    dst.attrs.splice(to < 0 ? dst.attrs.length : to + (after ? 1 : 0), 0, ref);
    // 落点层的"底"也由位置说了算：搬到最左的是一枚 image，它就是对方的起始面；搬到最左的是别的
    // 步骤，页面那一侧的归一会把它挤回底位右边。这里不再替它挪 —— 挪了就等于"拖了又弹回去"。
    const spec = ATTR_TYPES[rec.type];
    if (spec.kind === 'generator' && spec.sync && attrEnabled(rec)) spec.sync(dst, rec);
    const { w, h } = nativeSize(dst.img);
    if (w && h) remapAttrFaces(dst, s => (s.width === w && s.height === h) ? s : stretchSurfaceTo(s, w, h));
    return true;
}

// ---- 出厂、迁移与视图 ----
// 老形状 (mask/decal/effects 三个自带字段) 换成 strip:按注册表的 `order` 排,于是迁移动画出来的
// 顺序就是这条管线原本的执行顺序。
function migrateAttrs(l) {
    const found = [];
    for (const type of Object.keys(ATTR_TYPES)) {
        const spec = ATTR_TYPES[type];
        // 没有老字段的类型 (Stash —— 它从来不是图层上的一个字段) 不参与迁移:不读、也不删。
        // 少了这一句,`delete l[undefined]` 会在每个图层上留一个叫 "undefined" 的属性。
        if (!spec.legacy) continue;
        // 第二个参数是图层本体:有的老字段是一对 (3D 的 three + sceneUid),fromLegacy 要两个一起读。
        const payload = spec.fromLegacy(l[spec.legacy], l);
        if (payload) found.push({ type, payload, order: spec.order });
    }
    found.sort((a, b) => a.order - b.order);
    l.attrs = [];
    for (const f of found) {
        const r = newAttrRecord(f.type, f.payload);
        if (r) l.attrs.push(r.id);
    }
    for (const type of Object.keys(ATTR_TYPES)) {
        const spec = ATTR_TYPES[type];
        if (spec.legacy) delete l[spec.legacy];
    }
    return l;
}

// 每个图层出厂都要过一次 (跟 attachSourceView 同一处,见 blend_node)。`maskCtx` / `decalCtx` 从此是
// 派生态:画布只有一个 2D 上下文,存一份在图层上就会在共享的那两枚 attribute 之间说谎。
function attachAttrView(l) {
    if (!l || l.isMaskLayer) return l;        // 那张层只有一个覆盖面,它不是 Decal attribute
    if (!Array.isArray(l.attrs)) migrateAttrs(l);
    for (const type of Object.keys(ATTR_TYPES)) {
        const spec = ATTR_TYPES[type];
        // 没有老字段的类型不建视图（Stash）。少了这一句它会在每个图层上盖一个叫 "undefined" 的属性。
        if (!spec.legacy) continue;
        if (spec.kind === 'surface') {
            Object.defineProperty(l, spec.legacy, {
                configurable: true,
                get() { return attrSurface(this, type); },
                set(v) { setAttrSurface(this, type, v); },
            });
            if (spec.ctx) Object.defineProperty(l, spec.ctx, {
                configurable: true,
                get() { return attrSurfaceCtx(this, type); },
            });
        } else if (spec.kind === 'chain') {
            Object.defineProperty(l, spec.legacy, {
                configurable: true,
                get() { return attrChain(this); },
                set(v) { setAttrChain(this, v); },
            });
        } else if (spec.kind === 'generator') {
            // 生成器的老名字读的是描述符 (文字的 l.text、方向的 l.dir);3D 的老名字是 `l.three`
            // 布尔 + `l.sceneUid` 一对,由 spec 自己说 (uidField)。写 null = 摘掉这一枚。
            Object.defineProperty(l, spec.legacy, {
                configurable: true,
                get() {
                    const r = findAttr(this, type);
                    if (!r) return null;
                    return spec.legacyGet ? spec.legacyGet(r) : r.desc;
                },
                set(v) {
                    let r = findAttr(this, type);
                    if (!v) { if (r) removeAttr(this, r.id); return; }
                    if (!r) r = insertAttr(this, type);
                    if (!r) return;
                    if (spec.legacySet) spec.legacySet(r, v);
                    else r.desc = v;
                    markAttrPainted(r);
                },
            });
            if (spec.uidField) Object.defineProperty(l, spec.uidField, {
                configurable: true,
                get() { const r = findAttr(this, type); return r ? (r.sceneUid || null) : null; },
                set(v) { const r = findAttr(this, type); if (r) r.sceneUid = v || null; },
            });
        }
    }
    return l;
}

// ---- 快照、克隆、读档 ----
// 存的是值 + **它自己的 guid**:guid 是这一枚 attribute 的身份,它随档走 —— 重放照号收下,所以特效里
// 指向某一枚 attribute 的引用 (Lighting 的 dirRef) 存进文件、重开还认得。同一枚被两层引用时,档里那
// 一个号在**一次重放**里只立一条记录 (byId),共指就此活过 undo 与 tab 往返。
function snapshotAttrs(l) {
    return attrRecordsOf(l).map(r => {
        const s = Object.assign({ id: r.id, type: r.type }, ATTR_TYPES[r.type].snap(r));
        if (!attrEnabled(r)) s.enabled = false;   // 稀疏:开着的不落字段,老读法也读得懂
        return s;
    });
}

// `list` 里的每一项是 `{ id?, type, surface|chain }`。读 .cud 与恢复快照共用这一条口子 —— 区别只在于
// 要不要按号分组 (`byId`)。没有号的条目 (v4 及更早的档、mergeLegacyGenerators 补的那几条) 现 mint,
// 新号从不与档里的号同形 (见 attrSalt),所以两条路都不可能顶掉别人手里的记录。
function adoptAttrPayloads(list, byId) {
    const refs = [];
    for (const raw of (list || [])) {
        // 老档写的是 'decal'：先改名再查表。查不到的类型照旧跳过（未知类型是"别的版本"的，
        // 但 decal 不是未知，它是改名 —— 两者在下面这一行分开）。
        const type = canonAttrType(raw && raw.type);
        const spec = raw && ATTR_TYPES[type];
        if (!spec) continue;
        let r = byId && raw.id ? byId.get(raw.id) : null;
        if (!r) {
            r = newAttrRecord(type, spec.load(raw), raw.id);
            if (byId && raw.id) byId.set(raw.id, r);
        }
        if (r) {
            if (raw && raw.enabled === false) r.enabled = false;
            refs.push(r.id);
        }
    }
    return refs;
}

// 复制图层时 attribute 一律"浅拷贝":自己那份数据完整另立 (面是新画布、链是深拷贝),guid 也是新的。
// 底位不在这一趟里:它是这一层的像素,走的是源图那套 (ownSource / shareSourceWith),复制完由那一步
// 装进副本的条带 —— 这里再拷一份,副本就会带着两条底位。
function cloneCanvasSurface(surface) {
    if (!surface) return null;
    const c = document.createElement('canvas');
    c.width = surface.width; c.height = surface.height;
    c.getContext('2d').drawImage(surface, 0, 0);
    return c;
}
function cloneAttrList(l) {
    const refs = [];
    for (const r of attrRecordsOf(l)) {
        if (isBaseAttr(r)) continue;
        const copy = newAttrRecord(r.type, ATTR_TYPES[r.type].clone(r, cloneCanvasSurface));
        if (!copy) continue;
        copy.enabled = attrEnabled(r);
        refs.push(copy.id);
    }
    return refs;
}

// 这张表只给活图层当视图用,不是仓库:没人指的记录当场放手 (历史各自存着值,不需要表替它们保管)。
function pruneAttrs() {
    for (const ref of [...attrRecords.keys()]) if (attrRefs(ref) === 0) attrRecords.delete(ref);
}
