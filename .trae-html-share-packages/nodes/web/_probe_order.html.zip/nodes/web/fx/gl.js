// ---- WebGL2 engine ----
// 特效链的执行内核:缓冲/纹理、三份共享着色器、Kawase 低通原语、链的调度与表面缓存。
// 各类特效的着色器与 pass 不在这里 —— 它们在自己的 fx/<effect>.js 里注册进来 (见 core.js)。
// 2/3/4 号缓冲是「公共借用区」:silhouette 特效 (内/外阴影) 用它们存形状与虚化,描边用 3/4 做距离场
// 乒乓、景深与泛光用它们存低通档位、锈蚀在三张之间轮换闸门/噪声场/破洞掩码 —— 同一条链里这些面每趟
// 都重算,所以互不污染,一套五张缓冲的显存预算也就不会随特效种类增长。
// 五张离屏缓冲按当前图层尺寸复用:0/1 = 色彩乒乓,2 = silhouette 原样,3/4 = 借用乒乓。
// 图层之间尺寸通常一致,所以一帧里多个图层走特效也不会反复分配。
const FX_MAX_PIXELS = 12e6;              // 5 × RGBA16F ≈ 480 MB 的地板,超过就整链跳过并说明原因
const FX_KAWASE_MAX_ITER = 8;            // 着色器里那个常数次循环的上界
// P3.7：全页只有一台 GL —— 特效引擎与合成器共用**显示面**那把上下文（见 fxglBindStage）。
// 以前 fxgl 自己造一块离屏画布：链的结果要先"抄回 2D 画布"，合成器再把它上传成纹理，一层每帧
// 两趟全幅搬运（回读 + 上传）。合成一个上下文之后，链的结果直接就是合成器能绑的那张纹理
// （applyLayerEffectsTexture → layerItem 的 tex 条目）：显示那条路上一趟搬运都不剩。
// 代价：默认帧缓冲从此是**显示面**，所有"抄回 2D 画布"的出口都要改成渲进 FBO 再 readPixels
// （见 fxglReadFace / applyLayerEffects），绝不能往默认帧缓冲上画。
let fxglStageBind = null;                // { canvas, gl } —— 绑定的显示面（没绑就自造一块离屏的）
let fxglShared = false;                  // fxgl.canvas 是借来的显示面：不许改它的尺寸
const fxgl = {
    gl: null, dead: '', skip: '', w: 0, h: 0, fmt: null, vao: null, maxTex: 0,
    off: [], texSrc: null, texMask: null, texMap: null, texMap2: null, texLut: null, progs: null, canvas: null, hasMask: 0, hasMap2: 0,
    // 记账 (P3.1):合成侧要证明"每层少了一次 upload",只能数出来 —— upload = 画布进纹理的次数,
    // readback = 把结果抄回 canvas 的次数, pub = 只留纹理、不回读的出口次数。探针读它,别拿它做判断。
    stats: { upload: 0, readback: 0, pub: 0, paintBegin: 0, paintInk: 0, paintPresent: 0 },
};

const FX_VS = `#version 300 es
in vec2 aPos;
out vec2 vUV;
void main() { vUV = aPos * 0.5 + 0.5; gl_Position = vec4(aPos, 0.0, 1.0); }`;

// silhouette:特效眼里唯一的「形状」= 图层 alpha × 蒙版 alpha,存进四个通道。
const FX_FS_SIL = `#version 300 es
precision highp float;
in vec2 vUV;
layout(location = 0) out vec4 Frag;
uniform sampler2D uSrc;
uniform sampler2D uMask;
uniform int uHasMask;
void main() {
    float a = texture(uSrc, vUV).a;
    if (uHasMask == 1) a *= texture(uMask, vUV).a;
    Frag = vec4(a, a, a, a);
}`;

// dual-filtering:一个 pass 里做 uIter 次抽样,每次恒定 4 个抽样点(一对正交十字)、与半径无关。
// 十字的朝向逐迭代转 45°、起点 22.5°,down/up 两趟用 uPhase 再错一格:旧写法四角永远落在两条对角
// 线上,半径大而迭代少时高反差边缘就长出肉眼可见的**十字纹**;换成旋转基后各向同性,抽样数与半径
// 刻度都没变。
// uAlphaOnly=1 是 silhouette 的模式(数据只在 alpha 上,走纯加权平均);=0 是色彩模式 ——
// 每个抽样先预乘再累加,最后用「预乘均值 / alpha 均值」除回直通色,alpha 通道输出同一个 alpha
// 均值。链**会**重塑不透明度(模糊/运动模糊/马赛克都把软边吹开),色彩归一化保证透明边缘
// 不把颜色拽向黑(正是多趟累加最容易踩的坑)。uIter=0 恰好是恒等拷贝,色彩链用它起步。
const FX_FS_BOX = `#version 300 es
precision highp float;
in vec2 vUV;
layout(location = 0) out vec4 Frag;
uniform sampler2D uTex;
uniform vec2 uTexel;
uniform vec2 uStart;
uniform vec2 uDelta;
uniform int uIter;
uniform int uAlphaOnly;
uniform int uPhase;
void main() {
    vec4 c0 = texture(uTex, vUV);
    vec3 acc = c0.rgb * c0.a;
    float aAcc = c0.a;
    float wAcc = 1.0;
    for (int i = 0; i < ${FX_KAWASE_MAX_ITER}; i++) {
        if (i >= uIter) break;
        float k = float(i);
        // 四个抽样点是**一对正交的十字**,距离沿用旧四角的 |r|·√2 刻度;十字本身每迭代转 45°、
        // 起点 22.5°。4 阶矩上单十字已经各向同性(E[X^4]+E[Y^4] = 6·E[X²Y²] 在 θ=22.5° 时成立),
        // 相邻迭代再互补一次,所以既没有 × 也没有 +,而抽样数一个没多。
        float d = (uStart + uDelta * k).x * 1.4142135;
        float ang = (k + float(uPhase)) * 0.7853982 + 0.3926991;
        vec2 dir = vec2(cos(ang), sin(ang)) * d;
        vec2 u = vec2(dir.x * uTexel.x, dir.y * uTexel.y);
        vec2 v = vec2(-dir.y * uTexel.x, dir.x * uTexel.y);
        float w = 1.0 + k;
        vec4 s1 = texture(uTex, vUV + u);
        vec4 s2 = texture(uTex, vUV - u);
        vec4 s3 = texture(uTex, vUV + v);
        vec4 s4 = texture(uTex, vUV - v);
        acc += w * (s1.rgb * s1.a + s2.rgb * s2.a + s3.rgb * s3.a + s4.rgb * s4.a);
        aAcc += w * (s1.a + s2.a + s3.a + s4.a);
        wAcc += 4.0 * w;
    }
    float aAvg = aAcc / wAcc;
    if (uAlphaOnly == 1) { Frag = vec4(aAvg, aAvg, aAvg, aAvg); return; }
    Frag = vec4(clamp(acc / max(aAcc, 1e-5), 0.0, 1.0), clamp(aAvg, 0.0, 1.0));
}`;
// 出口:色彩缓冲是直通 alpha,而 WebGL canvas 被 drawImage 读走时按预乘解释,所以在这里乘一次。
const FX_FS_PRESENT = `#version 300 es
precision highp float;
in vec2 vUV;
layout(location = 0) out vec4 Frag;
uniform sampler2D uTex;
void main() {
    vec4 c = texture(uTex, vUV);
    Frag = vec4(c.rgb * c.a, c.a);
}`;
// 笔刷落点 (P3.1):两张直通 alpha 的面在着色器里合成,不经过 canvas 的 destination-in/out。
//   uMode = 0  src over dst  —— 墨盖到 decal 上、decal 盖到 base 上,都是这一句;
//   uMode = 1  dst dest-out src —— 橡皮:只擦 dst 的 alpha,颜色原样留着(与 canvas 的 destination-out 同义)。
// 两张面都已是直通 alpha,所以这里先把 rgb 预乘、算完再除回去;与 canvas 2D 的 source-over 同一公式。
const FX_FS_INK = `#version 300 es
precision highp float;
in vec2 vUV;
layout(location = 0) out vec4 Frag;
uniform sampler2D uDst;
uniform sampler2D uSrc;
uniform int uMode;
void main() {
    vec4 d = texture(uDst, vUV);
    vec4 s = texture(uSrc, vUV);
    if (uMode == 1) { Frag = vec4(d.rgb, d.a * (1.0 - s.a)); return; }
    float a = s.a + d.a * (1.0 - s.a);
    vec3 c = a > 0.0 ? (s.rgb * s.a + d.rgb * d.a * (1.0 - s.a)) / a : vec3(0.0);
    Frag = vec4(c, a);
}`;

function fxglCompile(gl, type, src) {
    const s = gl.createShader(type);
    gl.shaderSource(s, src);
    gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) {
        fxgl.dead = 'shader: ' + (gl.getShaderInfoLog(s) || 'failed');
        return null;
    }
    return s;
}

function fxglProgram(gl, name, fragSrc) {
    const vs = fxglCompile(gl, gl.VERTEX_SHADER, FX_VS);
    const fs = fxglCompile(gl, gl.FRAGMENT_SHADER, fragSrc);
    if (!vs || !fs) return null;
    const p = gl.createProgram();
    gl.attachShader(p, vs);
    gl.attachShader(p, fs);
    // 钉死 aPos = location 0:所有程序共用同一个 VAO,Attribute 必须落在同一处。
    gl.bindAttribLocation(p, 0, 'aPos');
    gl.linkProgram(p);
    gl.deleteShader(vs);
    gl.deleteShader(fs);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) {
        fxgl.dead = 'link ' + name + ': ' + (gl.getProgramInfoLog(p) || 'failed');
        return null;
    }
    return { p, u: {} };
}

function fxglU(prog, name) {
    if (!(name in prog.u)) prog.u[name] = fxgl.gl.getUniformLocation(prog.p, name);
    return prog.u[name];
}

/** 把这台引擎绑到**显示面**那把上下文上（页面在拿到 stage 上下文之后、任何特效调用之前喊一次）。
 *  必须在 fxglInit 之前——它就是 Init 要用的那台上下文。 */
function fxglBindStage(canvas, gl) {
    if (!canvas || !gl) return false;
    if (fxgl.gl === gl && fxglShared) return true;
    if (fxgl.gl && fxgl.gl !== gl) {
        // 之前自立过一台：把那边的缓冲丢掉，别把别人的上下文里的对象留着。
        try {
            for (const b of fxgl.off) { fxgl.gl.deleteFramebuffer(b.fb); fxgl.gl.deleteTexture(b.tex); }
            if (fxglOut) { fxgl.gl.deleteFramebuffer(fxglOut.fb); fxgl.gl.deleteTexture(fxglOut.tex); }
            for (const [, p] of fxglPub.byKey) { fxgl.gl.deleteFramebuffer(p.fb); fxgl.gl.deleteTexture(p.tex); }
        } catch (e) { /* 上下文已经没了 */ }
    }
    fxglStageBind = { canvas, gl };
    fxgl.gl = null; fxgl.dead = ''; fxgl.progs = null; fxgl.vao = null;
    fxgl.off = []; fxgl.w = 0; fxgl.h = 0;
    fxglOut = null;
    fxglPub.list = []; fxglPub.byKey = new Map(); fxglPub.used = 0;
    return true;
}

function fxglInit() {
    if (fxgl.gl || fxgl.dead) return fxgl.gl;
    const bound = fxglStageBind;
    const canvas = bound ? bound.canvas : document.createElement('canvas');
    const gl = bound ? bound.gl
        : canvas.getContext('webgl2', { alpha: true, antialias: false, depth: false, stencil: false, premultipliedAlpha: true, preserveDrawingBuffer: false });
    if (!gl) { fxgl.dead = 'no WebGL2'; return null; }
    fxgl.gl = gl;
    fxgl.canvas = canvas;
    fxglShared = !!bound;
    fxgl.maxTex = gl.getParameter(gl.MAX_TEXTURE_SIZE) | 0;
    // 可滤色的半浮点是这套算法最合适的落点:32F 还额外要 OES_texture_float_linear 才能做
    // dual-filtering 依赖的线性抽样,而 16F 在 WebGL2 里既可渲又可滤。都没有就退回 8 位。
    if (gl.getExtension('EXT_color_buffer_float') || gl.getExtension('EXT_color_buffer_half_float')) {
        fxgl.fmt = { internal: gl.RGBA16F, type: gl.HALF_FLOAT };
    } else {
        fxgl.fmt = { internal: gl.RGBA8, type: gl.UNSIGNED_BYTE };
    }
    // 引擎只有三张着色器:形状、Kawase 低通、出口。其余全部由注册表报上来 —— 每类特效把
    // 自己的 fragment 挂在 shaders 上,新增特效不必回来改这张列表。
    const progs = {
        sil: fxglProgram(gl, 'sil', FX_FS_SIL),
        box: fxglProgram(gl, 'box', FX_FS_BOX),
        present: fxglProgram(gl, 'present', FX_FS_PRESENT),
        ink: fxglProgram(gl, 'ink', FX_FS_INK),
    };
    let ready = progs.sil && progs.box && progs.present && progs.ink;
    for (const spec of Object.values(EFFECT_TYPES)) {
        for (const name of Object.keys(spec.shaders || {})) {
            progs[name] = fxglProgram(gl, name, spec.shaders[name]);
            // 失败也要把剩下的编完:fxgl.dead 里留下的是最后那个原因,而整链一次都不该跑半截。
            if (!progs[name]) ready = false;
        }
    }
    if (!ready) { fxgl.gl = null; return null; }
    fxgl.progs = progs;
    const vao = gl.createVertexArray();
    gl.bindVertexArray(vao);
    const vbo = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
    // 覆盖全域的 TRIANGLE_STRIP。上传时开 UNPACK_FLIP_Y,纹理与视口同为 y 向上,所以着色器的
    // vUV 与图像同向;画布里「向下」的偏移要在 JS 侧把 y 取负再传(见 fxglDirUV)。
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    gl.bindVertexArray(null);
    fxgl.vao = vao;
    // texLut 是曲线那类特效的查表位:内容逐次上传,所以这里只备好 LINEAR + CLAMP 的采样状态。
    for (const key of ['texSrc', 'texMask', 'texMap', 'texMap2', 'texLut']) {
        const t = gl.createTexture();
        gl.bindTexture(gl.TEXTURE_2D, t);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        fxgl[key] = t;
    }
    return gl;
}

function fxglMakeBuffer(gl, w, h, fmt) {
    const f = fmt || fxgl.fmt;
    const tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texImage2D(gl.TEXTURE_2D, 0, f.internal, w, h, 0, gl.RGBA, f.type, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    const fb = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
    const ok = gl.checkFramebufferStatus(gl.FRAMEBUFFER) === gl.FRAMEBUFFER_COMPLETE;
    return { tex, fb, ok, w, h, fmt: f };
}

function fxglResize(gl, w, h) {
    if (fxgl.w === w && fxgl.h === h && fxgl.off.length === 5) return true;
    if (w * h > FX_MAX_PIXELS) { fxgl.skip = 'layer too large for the effect chain'; return false; }
    const maxSide = fxgl.maxTex;
    if (w > maxSide || h > maxSide) { fxgl.skip = 'layer exceeds the texture limit'; return false; }
    for (const b of fxgl.off) { gl.deleteFramebuffer(b.fb); gl.deleteTexture(b.tex); }
    fxgl.off = [];
    for (let i = 0; i < 5; i++) {
        const b = fxglMakeBuffer(gl, w, h);
        if (!b.ok) { fxgl.dead = 'framebuffer incomplete'; fxgl.gl = null; return false; }
        fxgl.off.push(b);
    }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    fxgl.w = w;
    fxgl.h = h;
    // 借来的显示面**不许动尺寸**（那是画布本身，改一下就等于清屏 + 换栅格）。
    if (!fxglShared) { fxgl.canvas.width = w; fxgl.canvas.height = h; }
    return true;
}

function fxglUploadCanvas(tex, src) {
    const gl = fxgl.gl;
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
    // 这台上下文会被合成器借去出图 (P3.1),而它上传画布时要把 UNPACK_PREMULTIPLY 开成 true。
    // 链与笔刷这边的面一律是**直通 alpha**(预乘由出口的 present 那一步做),所以这里必须钉死 false:
    // 否则借出去一趟之后,下一次上传就被预乘一次,再进 present 就是二次预乘(实测 maxdiff 22)。
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, src);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
    fxgl.stats.upload++;
}

// dst = null 即画进默认缓冲(那张用于读回的 GL canvas)。vp 是可选的「这一趟只渲染多大一块」:
// 尺寸随级往下缩的那种面(光照的高度场金字塔)不必为此再写一条 pass 循环,默认照旧是整张面。
function fxglRunPass(dst, prog, setup, vp) {
    const gl = fxgl.gl;
    gl.bindFramebuffer(gl.FRAMEBUFFER, dst ? dst.fb : null);
    gl.viewport(0, 0, vp ? vp.w : fxgl.w, vp ? vp.h : fxgl.h);
    gl.useProgram(prog.p);
    gl.bindVertexArray(fxgl.vao);
    // 合成器会借这台上下文出图(P3.1),它会开混合 —— 链条这边的每一趟都必须是不混合的覆盖写,
    // 否则一条链会在上一趟的结果上再混一次。默认状态本来就不混合,这里只是把它钉死。
    gl.disable(gl.BLEND);
    setup(prog);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
}

function fxglBindTex(prog, name, tex, unit) {
    const gl = fxgl.gl;
    const loc = fxglU(prog, name);
    if (!loc) return;
    gl.activeTexture(gl.TEXTURE0 + unit);
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.uniform1i(loc, unit);
}

// ---- 出口③：把一块渲染面抄成 2D 像素（单上下文之后的"抄回画布"那条路）------------------------
// 以前这一趟是"present 到默认帧缓冲,再 drawImage(fxgl.canvas)"。现在默认帧缓冲就是显示面,
// 往那儿画等于把屏幕糊掉,所以改成:渲进一块自己的 RGBA8 面 → readPixels → 还原成画布口径。
// 两个必须对齐的细节：
//   · **y 翻转**：FBO 的第 0 行是图像下边，画布 ImageData 的第 0 行是上边。
//   · **反预乘**：present 出口写的是预乘 alpha（与"画布被浏览器按预乘解释"同口径），而 2D 画布
//     存的是直通 alpha —— putImageData 不做这件事，得自己对回来（与 drawImage 那条老路同一个公式）。
let fxglOut = null;
function fxglOutFace(w, h) {
    const gl = fxgl.gl;
    if (!gl) return null;
    if (fxglOut && fxglOut.w === w && fxglOut.h === h) return fxglOut;
    if (fxglOut) { gl.deleteFramebuffer(fxglOut.fb); gl.deleteTexture(fxglOut.tex); fxglOut = null; }
    const b = fxglMakeBuffer(gl, w, h, FX_PUB_FMT());
    if (!b.ok) { fxgl.dead = 'framebuffer incomplete (canvas out)'; return null; }
    fxglOut = b;
    return b;
}

/** 一块渲染面 → ImageData（画布口径：第 0 行是图像上边、颜色是直通 alpha）。 */
function fxglReadFace(buf, w, h) {
    const gl = fxgl.gl;
    if (!gl || !buf) return null;
    gl.bindFramebuffer(gl.FRAMEBUFFER, buf.fb);
    const px = new Uint8Array(w * h * 4);
    try { gl.readPixels(0, 0, w, h, gl.RGBA, gl.UNSIGNED_BYTE, px); }
    catch (e) { gl.bindFramebuffer(gl.FRAMEBUFFER, null); return null; }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    const out = new Uint8ClampedArray(w * h * 4);
    const row = w * 4;
    for (let y = 0; y < h; y++) {
        let s = (h - 1 - y) * row, d = y * row;
        for (let x = 0; x < w; x++, s += 4, d += 4) {
            const a = px[s + 3];
            if (a === 255 || a === 0) {
                out[d] = a === 255 ? px[s] : 0; out[d + 1] = a === 255 ? px[s + 1] : 0;
                out[d + 2] = a === 255 ? px[s + 2] : 0; out[d + 3] = a;
            } else {
                // 反预乘：c = c_pm * 255 / a，四舍五入（与 drawImage 从预乘画布读数同一条公式）。
                const inv = 255 / a;
                out[d] = Math.min(255, Math.round(px[s] * inv));
                out[d + 1] = Math.min(255, Math.round(px[s + 1] * inv));
                out[d + 2] = Math.min(255, Math.round(px[s + 2] * inv));
                out[d + 3] = a;
            }
        }
    }
    return new ImageData(out, w, h);
}

// uStart/uDelta 以 texel 计,着色器再乘 uTexel。phase 只决定抽样朝向从哪一路起(对角/轴向),
// down 与 up 各取 0/1,两趟的朝向正好互换。同一份着色器也修好了 silhouette 的高斯。
function fxglBox(dst, srcTex, start, delta, iter, alphaOnly, phase) {
    const gl = fxgl.gl;
    fxglRunPass(dst, fxgl.progs.box, p => {
        fxglBindTex(p, 'uTex', srcTex, 0);
        gl.uniform2f(fxglU(p, 'uTexel'), 1 / fxgl.w, 1 / fxgl.h);
        gl.uniform2f(fxglU(p, 'uStart'), start, start);
        gl.uniform2f(fxglU(p, 'uDelta'), delta, delta);
        gl.uniform1i(fxglU(p, 'uIter'), iter);
        gl.uniform1i(fxglU(p, 'uAlphaOnly'), alphaOnly ? 1 : 0);
        gl.uniform1i(fxglU(p, 'uPhase'), phase ? 1 : 0);
    });
}

// 半径 R = n*start + delta*n(n-1)/2;取 start=delta 解出 step,一趟由小到大、一趟由小到大退回,
// 抽样数只随 n 线性增长(n = radius/5 夹在 1..8),与半径本身脱钩。朝向旋转把十字摊平是在**同一
// 个 n** 上完成的,所以这套抽样预算一个字都没动。
function fxglKawaseIters(radius) {
    return Math.max(1, Math.min(FX_KAWASE_MAX_ITER, Math.round(radius / 5)));
}

function fxglGauss(dst, srcTex, mid, radius) {
    const n = fxglKawaseIters(radius);
    const step = (2 * radius) / (n * (n + 1));
    fxglBox(mid, srcTex, step, step, n, false, 0);                     // down
    fxglBox(dst, mid.tex, step * (n - 1), -step, n, false, 1);         // up
}

// 借用面 (2/3/4) 之间的 alpha 低通,默认「形状 2 → 中转 3 → 结果 4」:内/外阴影的虚化、描边与锈蚀
// 的闸门都走这一条。一条链里想把别的中间量也糊一下 (锈蚀糊噪声场、糊破洞掩码) 就点名 src/mid/dst,
// 不必再写一份近似函数 —— 显存预算还是那五张面。
function fxglSilGauss(radius, src = 2, mid = 3, dst = 4) {
    const n = fxglKawaseIters(radius);
    const step = (2 * radius) / (n * (n + 1));
    fxglBox(fxgl.off[mid], fxgl.off[src].tex, step, step, n, true, 0);                     // down
    fxglBox(fxgl.off[dst], fxgl.off[mid].tex, step * (n - 1), -step, n, true, 1);          // up
}

// 画布坐标(0°=右、90°=下,y 向下增长)→ 纹理 UV(GL 的 y 向上,上传时已翻)。
function fxglDirUV(angleDeg, distance) {
    const a = angleDeg * Math.PI / 180;
    return { x: Math.cos(a) * distance, y: -Math.sin(a) * distance };
}

function fxHexToRgb01(hex) {
    let s = String(hex || '').replace('#', '').trim();
    if (s.length === 3) s = s.split('').map(c => c + c).join('');
    const v = parseInt(s, 16);
    if (!isFinite(v) || s.length !== 6) return [0, 0, 0];
    return [((v >> 16) & 255) / 255, ((v >> 8) & 255) / 255, (v & 255) / 255];
}

// 这条链最近一次跑不动的原因,按**记录**存一份。fxgl.skip 是全工程唯一那份「最近一次跑链」的读数,
// 状态栏和 Apply 命令读它没问题,侧栏的容器不行:render 先把每个图层、每枚容器都折完,然后才建那批
// DOM,于是最晚跑过的那条链把话说到所有容器头上 —— 绑好了深度图的那块也会写上 "no depth map bound"。
// 键是记录对象本身 (条带上的记录跨 render 是同一个,见 fxResolved 拿面身份比缓存),层删了它就跟着没了。
const fxChainSkip = new WeakMap();
function fxChainSkipReason(r) { return (r && fxChainSkip.get(r)) || ''; }

// 就地跑一条链,结果停在 fxgl.off[slot] 的**纹理**上(直通 alpha,还没预乘)。返回 { slot } 或 null。
// 这是唯一的链执行体 —— 两个出口(present 回 canvas / 发布成纹理)只决定"结果怎么交出去",不碰像素。
// 返回 null = 整链没跑(不支持 / 太大),surface 原样留着;fxgl.skip 带上原因,让状态栏能说清楚。
// `opts.rec` = 这一枚 Effects attribute 的记录 (读它自己那条链), `opts.mask` = 它左边那些蒙版与起来的
// 覆盖率。两个都不传 = 读图层上那三个老名字的最左边那一枚 (还没理解 strip 的调用点,见 attr/core.js)。
function fxglChainRun(l, surface, opts) {
    const o = opts || {};
    const chain = o.rec ? activeEffects(l, o.rec) : activeEffects(l);
    const mask = ('mask' in o) ? o.mask : l.mask;
    fxgl.skip = '';
    if (o.rec) fxChainSkip.delete(o.rec);
    // 全局那句照旧写 (状态栏要的是「最近一次」),这一枚记录那句同时写进 fxChainSkip。
    const note = () => { if (o.rec && fxgl.skip) fxChainSkip.set(o.rec, fxgl.skip); };
    if (!chain.length) return null;
    const gl = fxglInit();
    if (!gl) { fxgl.skip = fxgl.dead || 'WebGL2'; note(); return null; }
    const w = surface.width, h = surface.height;
    if (!w || !h || !fxglResize(gl, w, h)) { note(); return null; }

    fxglUploadCanvas(fxgl.texSrc, surface);
    fxgl.hasMask = 0;
    if (mask && mask.width === w && mask.height === h) {
        fxglUploadCanvas(fxgl.texMask, mask);
        fxgl.hasMask = 1;
    }
    // 色彩链恒定在 off[0]/off[1] 之间乒乓;起点是 texSrc 的一次恒等拷贝(uIter=0)。
    const col = { slot: 0 };
    fxglBox(fxgl.off[0], fxgl.texSrc, 0, 0, 0, false);
    for (const effect of chain) {
        const p = effectParams(effect);
        const spec = EFFECT_TYPES[effect.type];
        // 槽位由注册数据声明 (见 fx/maps.js 的 fxMapSlots):主槽 params.map → texMap,副槽
        // spec.needsMap2 → texMap2。「这个模式要不要这张图」由该槽自己的 when 报一句 —— 否则中性
        // 模式会因为「没绑图」被整条跳过,而那模式根本不需要图。
        // 主槽解析不出像素就整条跳过:拿一张黑图当深度图去打光,比不打光更糟;副槽是可缺的,没绑
        // 就把 hasMap2 归零,由该特效自己退化成单图算法 (见 fx/warp.js 的几何)。
        // 原因一律写在链上 (fxgl.skip),不许静默。
        fxgl.hasMap2 = 0;
        let mapMiss = '';
        for (const slot of fxMapSlots(effect)) {
            if (slot.when && !slot.when(p)) continue;
            const ref = fxMapRef(effect, slot.key);
            const img = fxMapImage(ref);
            if (!img) {
                if (slot.optional) continue;
                // 说的是哪一张图 = 注册表里那个角色。泛写 "map" 在占两个槽的特效上说不清缺的是深度
                // 还是法线,而这条原因就写在链上,是用户唯一的线索。
                const nm = `${slot.role.toLowerCase()} map`;
                mapMiss = `${spec.label}: ${ref ? `${nm} not ready` : `no ${nm} bound`}`;
                break;
            }
            const n = nativeSize(img);
            if (n.w > fxgl.maxTex || n.h > fxgl.maxTex) {
                mapMiss = `${spec.label}: ${slot.role.toLowerCase()} map is ${n.w}×${n.h}, over the texture limit`;
                break;
            }
            fxglUploadCanvas(slot.key === 'map' ? fxgl.texMap : fxgl.texMap2, img);
            if (slot.key !== 'map') fxgl.hasMap2 = 1;
        }
        if (mapMiss) { fxgl.skip = mapMiss; note(); continue; }
        // 跑不动的特效自己写 fxgl.skip (参数为 0 时直接原样返回),引擎只负责把贴图备好。
        // effect 一起传:绑定贴图的尺寸也是该特效的判断依据 (见 fx/tone_map.js 的布局识别)。
        // l 也一起传:有的特效吃的几何是**图层盒子在画布上的位置**,不只是它自己的网格 (见 fx/warp.js 的深度)。
        spec.run(col, p, effect, l);
    }
    // 特效自己写在链上的那句也算这条记录的原因 (参数为 0 之类它自己决定不跑的情形)。
    note();
    return { slot: col.slot };
}

// 出口①(P2 起就在用):把结果抄回 surface。链的像素一落地就成了"一张画布",所以它必须过一遍
// present(直通 α → 预乘)再还原成直通 alpha 才画得进去。
// 单上下文(P3.7)之后这一趟不能画进默认帧缓冲（那是显示面）—— 渲进一块临时面,readPixels 抄回。
// 返回 false = 整链没跑,surface 原样留着。
function applyLayerEffects(l, surface, opts) {
    const r = fxglChainRun(l, surface, opts);
    if (!r) return false;
    const w = surface.width, h = surface.height;
    const out = fxglOutFace(w, h);
    if (!out) return false;
    fxglRunPass(out, fxgl.progs.present, pr => fxglBindTex(pr, 'uTex', fxgl.off[r.slot].tex, 0), { w, h });
    const img = fxglReadFace(out, w, h);
    if (!img) return false;
    const c2 = surface.getContext('2d');
    resetCtx(c2);
    c2.clearRect(0, 0, w, h);
    c2.putImageData(img, 0, 0);
    fxgl.stats.readback++;
    return true;
}

// 出口②(P3.1 的"编辑写纹理"):结果**不回读**,直接留在纹理上交给合成器。
// 交出去的那张面来自**发布区**(不是 off[]) —— off[] 是公共借用区,下一条链就把 0/1 覆盖了,而合成
// 要按图层次序贴很多层,每层的结果得同时存在。发布区是预乘 8 位:与"抄回 canvas 再 texImage2D"那条
// 老路逐位同口径(那两步省掉的正是这一步拷贝),所以合成结果不许因为换了出口而变。
// `opts.slotKey`（图层 id）= 走**按 key 固定**的那一页：同一层每帧拿到的纹理是同一张，调用方才能
// 按内容签名把上一帧的结果直接再用（显示面那条路，见 fxResolvedTexture）。
// 返回 { gl, tex, w, h } 或 null(没跑 = 调用方照老路用 canvas)。
function applyLayerEffectsTexture(l, surface, opts) {
    const r = fxglChainRun(l, surface, opts);
    if (!r) return null;
    const pub = (opts && opts.slotKey)
        ? fxglPubSlot(opts.slotKey, fxgl.w, fxgl.h)
        : fxglPubTake(fxgl.w, fxgl.h);
    if (!pub) return null;
    fxglRunPass(pub, fxgl.progs.present, pr => fxglBindTex(pr, 'uTex', fxgl.off[r.slot].tex, 0));
    fxgl.stats.pub++;
    return { gl: fxgl.gl, tex: pub.tex, w: pub.w, h: pub.h };
}

// 发布区:按需生长的纹理池,池里的面跨帧复用(每次合成开头 fxglPubReset 把 used 归零)。
// 峰值条数 = 一帧里同时带着链结果的层数,不是历史总数 —— 这就是不设上限也安全的原因。
// `byKey` 是**按图层固定**的那一路（显示面那条路用）：同一层每帧拿到的永远是同一页，
// 所以"内容签名没变"时可以直接把上一帧那张纹理再交出去，一帧都不用重跑。
const fxglPub = { list: [], used: 0, byKey: new Map() };
const FX_PUB_FMT = () => ({ internal: fxgl.gl.RGBA8, type: fxgl.gl.UNSIGNED_BYTE });

function fxglPubReset() { fxglPub.used = 0; }

function fxglPubTake(w, h) {
    const gl = fxgl.gl;
    let p = fxglPub.list[fxglPub.used];
    if (p && (p.w !== w || p.h !== h)) {
        gl.deleteFramebuffer(p.fb);
        gl.deleteTexture(p.tex);
        p = null;
    }
    if (!p) {
        const b = fxglMakeBuffer(gl, w, h, FX_PUB_FMT());
        if (!b.ok) { fxgl.dead = 'framebuffer incomplete (publish)'; return null; }
        p = b;
        fxglPub.list[fxglPub.used] = p;
    }
    fxglPub.used++;
    return p;
}

/** 按 key（图层 id）固定的一页发布面：同一层每帧都拿到它，缓存才敢把纹理交出去。 */
function fxglPubSlot(key, w, h) {
    const gl = fxgl.gl;
    const k = String(key);
    let p = fxglPub.byKey.get(k);
    if (p && (p.w !== w || p.h !== h)) {
        gl.deleteFramebuffer(p.fb);
        gl.deleteTexture(p.tex);
        fxglPub.byKey.delete(k);
        p = null;
    }
    if (!p) {
        const b = fxglMakeBuffer(gl, w, h, FX_PUB_FMT());
        if (!b.ok) { fxgl.dead = 'framebuffer incomplete (publish slot)'; return null; }
        p = b;
        fxglPub.byKey.set(k, p);
    }
    return p;
}

// 合成器往"这台 GL 的那块画布"出图之前先对这一句:让画布尺寸与它要画的网格一致,并把发布区开新一页。
// 返回 { gl, canvas }(借出去的上下文),取不到 GL 就 null —— 调用方据此决定还能不能用纹理入口。
// **共用显示面之后它一律回 null**（P3.7）：这条"借画布"的路是给 render-plan 那个离线合成器用的，
// 它会在借来的画布上直接合成 —— 那块现在是屏幕本身，借出去就等于把离线合成画到屏幕上。回 null
// 之后它走自己的离屏上下文（与没有 WebGL2 时同一条退路），像素结果不变。
function fxglStageSize(w, h) {
    if (fxglShared) return null;
    const gl = fxglInit();
    if (!gl) return null;
    if (fxgl.canvas.width !== w || fxgl.canvas.height !== h) {
        fxgl.canvas.width = w;
        fxgl.canvas.height = h;
    }
    fxglPubReset();
    return { gl, canvas: fxgl.canvas };
}

// ---- 图层表面的缓存 ----
// 失效信号用 surface 的**对象身份** + 一个**落笔代次**,不用版本号:笔刷下落笔前会 detachPaintSurface()
// 换上一份私有副本,stretch/resample/crop/bake 也都是整体替换那枚 attribute 的面,所以身份就是脏标记。
// 但身份只覆盖"换了对象":一笔之内的每一次 livePreviewStroke 都是**就地改写同一张 canvas**,起笔换过
// 一次身份之后,后面整笔都命中旧缓存 —— 画布上摆的是落笔第一点那刻的合成图,墨要等下一次按下才显形。
// 所以写表面的路径要 +1 那一枚 attribute 的 paintGen (画笔/橡皮走 livePreviewStroke,油漆桶自己 +1),
// 缓存键把条带上每一枚的代次都串进去 —— 见下面 fxResolved 的 gen。
// 代次不同而身份全同 = 只有墨变了 → 复用同一块缓存画布重画重跑,绝不新建 canvas:一笔几百帧就是一次
// 几百张画布的 GC。surface 只被这条缓存持有(快照存的是链的深拷贝,fxCache 从不进快照),接管它安全。
// 拖 transform 时身份、参数签名与代次都不变 → 命中缓存,特效链一帧都不会重跑 —— 这是绝大多数
// 特效想要的 (它们的输入只有像素与 params);真把画布几何当输入的特效 (Canvas 对齐的深度 warp) 靠
// spec.stamp 把那一句加进身份 (ext),否则它会钉在挪之前烘好的那份位移上。
// 文本层也吃这条恒等式,而且这不是偷懒:链跑在 syncTextBuffer 烘出的**盒子(=画布像素)分辨率**
// 缓冲上,特效结果和文字本身一样以显示分辨率光栅化,放大盒子绝不会糊。代价是 resize 帧缓冲换
// 身份、链会重跑 —— 只发生在挂着启用链的文字层上,而特效参数按画布像素计正是这里要的读法。

const FX_CUT_ALL = () => true;

// 这枚 attribute 会在折叠出来的那张面上留下像素吗:停用的步骤不算 (数据还在,只是这一趟不出墨),
// 空面 = 没装 (attr/core.js 的规矩三),空链 / 全旁路 = 不跑,而 cut 说了算的那些蒙版这一趟只当
// silhouette 喂给右边的链,不当剪刀。
// 「绑了视频轨、但这一趟还没注入面」的贴片/蒙版**也算会出墨**：P3.7 之后显示那条路把整层直接交给
// 视频纹理（不造 2D 画布），而 2D 折叠的读者（缩略图 / 生成 / 后端分流）要自己现取一帧
// （见 fxDropStrip 里的 vidFrameFaceFor）。不这么认，这些层在 2D 那边会被判成"没东西"、出空图 ——
// 用户看到的就是"贴片绑的那张图没跟着更新"。
function attrInks(r, l, i, cut) {
    if (!attrEnabled(r)) return false;
    if (r.chain) return activeEffects(l, r).length > 0;
    if (!r.surface || !r.surface.width || !r.surface.height) {
        if (!r.frameTrack || typeof vidFrameFaceFor !== 'function') return false;
        return cut(r, i);
    }
    return cut(r, i);
}

// 分界线落在**最后一条会跑的链**上 (不是最后一枚做事的 attribute —— 贴片与蒙版本来就归后端重放)。
// 停用的容器不算:它这一趟不跑,前端不必替它折,后端也不必等它。
function lastChainIndex(l, recs) {
    for (let i = recs.length - 1; i >= 0; i--) {
        if (recs[i].chain && attrEnabled(recs[i]) && activeEffects(l, recs[i]).length) return i;
    }
    return -1;
}

function sameFaces(a, b) {
    return a.length === b.length && a.every((f, i) => f === b[i]);
}

// 把几张蒙版与成一张 (alpha 逐像素相乘),画进这块借用画布并归到 (w,h)。
let fxMaskCov = null;
function fxAndInto(masks, w, h) {
    if (!fxMaskCov) fxMaskCov = document.createElement('canvas');
    if (fxMaskCov.width !== w || fxMaskCov.height !== h) { fxMaskCov.width = w; fxMaskCov.height = h; }
    const o = fxMaskCov.getContext('2d');
    resetCtx(o);
    o.clearRect(0, 0, w, h);
    o.drawImage(masks[0], 0, 0, w, h);
    for (let i = 1; i < masks.length; i++) {
        o.globalCompositeOperation = 'destination-in';
        o.drawImage(masks[i], 0, 0, w, h);
        o.globalCompositeOperation = 'source-over';
    }
    return fxMaskCov;
}

// silhouette 用的那张覆盖率。尺寸与图层网格对不上的蒙版不参与 —— 沿用 applyLayerEffects 那条
// 「贴图必须与网格同尺寸」的老规矩;一张都不剩就当纯白 (hasMask=0);只有一张就把原面交出去,
// 不占那块借用画布。
function stripCoverage(masks, w, h) {
    const fit = masks.filter(s => s.width === w && s.height === h);
    if (!fit.length) return null;
    return fit.length === 1 ? fit[0] : fxAndInto(fit, w, h);
}

// ---- 条带折叠 (the fold) ----
// 图层表面 = 条带上从左到右**每一枚** attribute 顺序作用的结果（没有"隐式起点"了）。
// 规矩全在这一个循环里:
//   · 贴片（含底位）用 source-over 叠上去,蒙版用 destination-in 裁,各按**自己那个位置**发生,不再有谁是固定的
//     前一步或后一步 (所以 `Mask·Decal` 与 `Decal·Mask` 是两张不同的图:后者贴片的墨会被裁掉)。
//   · **底位也是条带上普通的一步** (`role:'base'` 只说明"它是这一层自己的图",不说明位置):拖到一条链
//     右边 = 那条链在画它之前跑,于是这条链不作用于它 —— 拖地完成的是一个真结果,不是换个说法。
//   · 每一枚蒙版同时是**它右边所有链**的 silhouette:一路攒着,交给下一条真跑的链与成的那张覆盖率。
//     注意是"它左边的全部",不是"距上一条链以来的那几枚" —— `Mask·Effects·Effects` 里两条链读同一张图。
//   · cut(r, i) 说这枚蒙版在这一趟里裁不裁。后端那两条通道把「最后一条启用链右边」的蒙版留给后端乘
//     (见 fxSplitForBackend / fxSurfaceForGenerate),前端这一趟就不能替它乘掉。
// 返回 false = 整趟没跑 (这层没什么可折的),surface 归调用方自己画。
// `overrideBase` 只给 Generate 那条路用:空层的底位换成噪声好让链有东西可跑,它不是 Board 上的像素。
function fxDropStrip(l, surface, overrideBase, thru, cut) {
    const recs = attrRecordsOf(l);
    const n = thru < 0 ? recs.length : Math.min(thru + 1, recs.length);
    const inks = [];
    for (let i = 0; i < n; i++) if (attrInks(recs[i], l, i, cut)) inks.push(recs[i]);
    if (!inks.length) return false;
    // 只有底位这一枚在做事 ⇒ 折出来与那张原图逐像素相同。照旧说"没得折":调用方各自拿 l.img 用,
    // 几十层的文档不该为了翻个案簿全幅重绘一遍 (那一趟还顺手换掉面的身份,缓存会全部失效)。
    if (inks.length === 1 && inks[0].role === 'base' && !overrideBase) return false;
    const w = surface.width, h = surface.height;
    const o = surface.getContext('2d');
    resetCtx(o);
    o.clearRect(0, 0, w, h);
    const left = [];              // 这条链左边那些蒙版 (与起来才是它的 silhouette)
    for (let i = 0; i < n; i++) {
        const r = recs[i];
        if (!attrEnabled(r)) continue;      // 停用 = 整枚跳过:不叠、不裁、也不给右边的链当 silhouette
        if (r.chain) {
            if (!activeEffects(l, r).length) continue;
            const prevSkip = fxgl.skip;         // 一条链跑不动不许盖掉前一条已经报过的原因
            applyLayerEffects(l, surface, { rec: r, mask: stripCoverage(left, w, h) });
            fxgl.skip = prevSkip || fxgl.skip;
            continue;
        }
        // 这一枚的面这一趟还没注入（显示那条路把整层直接交给视频纹理、不造画布）：2D 这边现取一帧。
        // 取不到（那条轨此刻没有可画的帧）= 这一枚这一趟什么都不出，与"停用一步"同一个结果。
        let s = overrideBase && r.role === 'base' ? overrideBase : r.surface;
        if ((!s || !s.width || !s.height) && r.frameTrack && typeof vidFrameFaceFor === 'function') {
            s = vidFrameFaceFor(r, w, h);
        }
        if (!s || !s.width || !s.height) continue;
        if (r.type === 'mask') {
            left.push(s);
            if (!cut(r, i)) continue;
        }
        o.globalCompositeOperation = r.type === 'mask' ? 'destination-in' : 'source-over';
        o.drawImage(s, 0, 0, w, h);
        o.globalCompositeOperation = 'source-over';
    }
    return true;
}

function fxScratch(w, h) {
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    return c;
}

// 被绑定为**镜面**的 plane 记录:本层条带上有 ssr 特效且 planeRef 指向本层条带上的记录时返回它。
// 它的取景记号 (盘面/箭头) 不能画进图层 —— 反射采样的是图层自己, 照到记号 = 倒影里长出盘面。
function ssrMirrorRecord(l) {
    for (const r of attrRecordsOf(l)) {
        if (!r.chain || !attrEnabled(r)) continue;
        for (const e of r.chain) {
            if (!e || e.type !== 'ssr' || e.enabled === false) continue;
            const rec = attrRecord(e.params && e.params.planeRef);
            if (rec && attrRefList(l).indexOf(rec.id) >= 0) return rec;
        }
    }
    return null;
}
// 折叠期间把镜面记录临时停用 (fn 内 enabled=false, 出口原样放回): 三条折叠入口 (结算/后端分流/
// Generate 出图) 都走这一句 —— 记号不进结算面、不进 src、不进 Generate 出图, 反射自然采不到它。
// 绑定方 (fxSSRPlane) 读的是记录本身, 停用不影响反射几何。
function fxMirrorHidden(l, fn) {
    const mirror = ssrMirrorRecord(l);
    const was = mirror ? mirror.enabled : null;
    if (mirror) mirror.enabled = false;
    try { return fn(); } finally { if (mirror) mirror.enabled = was; }
}

// ---- 预解码源 (prewarmed source) ----
// <img> 的像素是懒解码的:第一次 drawImage 才付解码税,图层多的文档就把这笔税全压在打开那几笔上。
// blob 到手时立刻 createImageBitmap 解一份 (池宽 8 —— 无界时几十张的解码会和 GL 编译抢机器),
// 记在 img 身份下;fxSrcOf 把它换给绘制侧当源。l.img 一处不动 —— 保存的字节复用表、naturalWidth、
// 列表缩略图全按 img 身份走,只换 drawImage 的输入。位图与 <img> 在 1:1 与 0.83 档逐字节相同,
// 缩小档有个别边缘像素的通道差 (0.35 档实测 max ~104) —— 各档实测见探针 5c/5d。
const fxSrcBitmaps = new WeakMap();
const fxWarmPool = (() => {
    let act = 0; const q = [];
    const next = () => { if (q.length && act < 8) q.shift()(); };
    return fn => new Promise((res, rej) => {
        const start = () => { act++; fn().then(v => { act--; next(); res(v); }, e => { act--; next(); rej(e); }); };
        act < 8 ? start() : q.push(start);
    });
})();
function fxWarmBitmap(img, blob) {
    if (!img || !blob || fxSrcBitmaps.has(img) || typeof createImageBitmap !== 'function') return;
    fxWarmPool(() => createImageBitmap(blob)).then(bm => {
        if (!fxSrcBitmaps.has(img)) fxSrcBitmaps.set(img, bm);
    }, () => { /* 解不动就继续走 <img>,老路照旧 */ });
}
// 绘制用的源:位图暖好了给它,没暖好原样还 <img>。
function fxSrcOf(img) { return (img && fxSrcBitmaps.get(img)) || img; }

// 画面那一趟:整条折完,蒙版一律裁。结果就是画布要盖的那张图,所以它带缓存 (注释见上)。
function fxResolved(l) {
    if (!l) return null;
    return fxMirrorHidden(l, () => {
    // 生成器的面先同步 (attr/core.js):ownsGrid 的文字/方向可能当场换底换格子,必须发生在
    // nativeSize 与早退判据**之前**,否则一枚还没算过面的记录会被当成"没装"。
    syncGeneratorFaces(l);
    // 格子问 `layerGridOf`(blend_node.html):底位有像素就听它;一张图都没有的层(Stash 那一类,
    // 像素全来自下面)听条带上第一枚有像素的步骤,再退到画布。以前这里读 `l.img`,那种层直接
    // 返回 null —— 整层不出现。
    const { w, h } = layerGridOf(l);
    if (!w || !h) return l.img || null;
    const recs = attrRecordsOf(l);
    // 纯像素层 (条带空着,或只挂了空蒙版) 每帧都走到这里就收工:签名与贴图戳一次都不算。
    if (!recs.some((r, i) => attrInks(r, l, i, FX_CUT_ALL))) return fxSrcOf(l.img);
    const sig = fxSignature(l);
    const maps = fxMapStamp(l);
    const ext = fxExternalStamp(l);
    // 落笔代次 = 图层自己那份像素的 + 条带上**每一枚面**的。共享的一面被别的层落一笔时,这一层的
    // l.paintGen 一动不动,而它这一串里的那一格变了 —— 只看图层自己就会把这层钉在旧结果上。
    const gen = (l.paintGen | 0) + attrPaintGens(l);
    const faces = recs.map(r => r.surface || null);
    const c = l.fxCache;
    if (c && c.w === w && c.h === h && c.img === l.img && sameFaces(c.faces, faces)
        && c.sig === sig && c.maps === maps && c.ext === ext && c.gen === gen) return c.surface;
    const reuse = !!(c && c.w === w && c.h === h && c.surface);
    const surface = reuse ? c.surface : fxScratch(w, h);
    if (!fxDropStrip(l, surface, null, -1, FX_CUT_ALL)) return fxSrcOf(l.img);
    l.fxCache = { w, h, img: l.img, faces, sig, maps, ext, gen, surface };
    // 命中缓存时 surface 是**同一块画布原地重画**的,身份键察觉不到「这一层现在长这样了」。Stash 层
    // 要认这一点 (它抄的是以下所有层的合成图),所以每重算一次就换一个代次 —— 见 blend_node.html 的
    // stashLayerKey。只有走了缓存路径 (条带上真有事) 的层才需要它:纯像素层的输入就是那张 img。
    l.fxResolveGen = (l.fxResolveGen | 0) + 1;
    return surface;
    });
}

// ---- 笔刷落点：图层纹理 (P3.1 余下) ----
// 一笔落在 decal 上时，**预览期间 2D 面一个字都不动**：墨直接进 GPU 的 decal 纹理，再由
// 「decal over base」的合成纹理交给显示 / 合成器；提交那一刻才把同一笔墨写回 2D 面（历史、存档、
// 导出读的仍是那张面）。所以下一帧看到的是纹理，不是把 2D 面重折一遍。
//
// 为什么拆成 decal/base 两张而不是往「整层结果」上直接盖墨：
//   · 层结果 = decal over base。source-over 可以结合，但橡皮是 destination-out —— 它只该擦 decal，
//     落在整层结果上会连 base 一起擦掉。两张面各自成立，两种笔都精确。
//   · base = 「把这一枚 decal 临时停用后折出来的那层」。这只在 decal 是最后一步时成立（否则它右边
//     的蒙版/链也得跟着重算），所以入口有一道判据（blend_node.html 的 gpuPaintEligible）。
//
// 纹理一律 RGBA8、直通 alpha（与链的中间面同口径）；ink 仍是一张 canvas，上传后由着色器合成 ——
// 没有 readback，也没有整层重折。
const fxPaintIds = new WeakMap();
let fxPaintSeq = 0;
function fxPaintId(o) {
    if (!o) return '0';
    let v = fxPaintIds.get(o);
    if (v === undefined) { v = ++fxPaintSeq; fxPaintIds.set(o, v); }
    return String(v);
}

// 与 fxResolved 的缓存键同义：面身份 + 落笔代次 + 链签名 + 贴图戳。只用于「下一次开始一笔时
// 2D 面是不是已经换过」，预览期间不拿它判活纹理（见 fxPaintBegin 的 live）。
function fxPaintLayerKey(l) {
    const n = nativeSize(l.img);
    let faces = '';
    for (const r of attrRecordsOf(l)) faces += ':' + fxPaintId(r.surface);
    return n.w + 'x' + n.h + ':' + fxPaintId(l.img) + faces + ':'
        + fxSignature(l) + ':' + fxMapStamp(l) + ':' + fxExternalStamp(l) + ':'
        + (l.paintGen | 0) + attrPaintGens(l);
}

const fxPaintCache = new WeakMap();
const FX_PAINT_FMT = () => ({ internal: fxgl.gl.RGBA8, type: fxgl.gl.UNSIGNED_BYTE });

function fxPaintBuffer(w, h) {
    const b = fxglMakeBuffer(fxgl.gl, w, h, FX_PAINT_FMT());
    if (!b.ok) { fxgl.dead = 'framebuffer incomplete (paint)'; return null; }
    return b;
}

// 一张面 → 一张纹理。尺寸按面自己的 natural size（l.img 可能是 <img>，width 未必等于像素宽）。
function fxPaintUpload(src) {
    const n = nativeSize(src);
    if (!n.w || !n.h) return null;
    const b = fxPaintBuffer(n.w, n.h);
    if (!b) return null;
    fxglUploadCanvas(b.tex, src);
    return b;
}

function fxPaintCompose(st) {
    const gl = fxgl.gl;
    fxglRunPass(st.composed, fxgl.progs.ink, p => {
        fxglBindTex(p, 'uDst', st.base.tex, 0);        // dst = base（这一层没有 decal 的样子）
        fxglBindTex(p, 'uSrc', st.decal[st.cur].tex, 1); // src = decal（这一笔的最新墨）
        gl.uniform1i(fxglU(p, 'uMode'), 0);
    }, { w: st.w, h: st.h });
    return true;
}

// 开始一笔：把 2D 面（decal）与「没有它的那层」（base）各上传一次，之后预览只动纹理。
// `rec` 是 decal 的 attribute 记录 —— 停用它只为折出 base，出口原样放回。
function fxPaintBegin(l, surface, rec) {
    const gl = fxglInit();
    if (!gl || !l || !surface || !rec) return false;
    const w = surface.width, h = surface.height;
    if (!w || !h) return false;
    let st = fxPaintCache.get(l);
    if (!st || st.w !== w || st.h !== h) {
        st = { w, h, decal: [null, null], cur: 0, base: null, composed: null, pub: null,
               ink: null, live: false, seq: 0, pubSeq: -1, key: '' };
        fxPaintCache.set(l, st);
    }
    for (const b of st.decal) if (b) { gl.deleteFramebuffer(b.fb); gl.deleteTexture(b.tex); }
    if (st.base) { gl.deleteFramebuffer(st.base.fb); gl.deleteTexture(st.base.tex); }
    if (st.composed) { gl.deleteFramebuffer(st.composed.fb); gl.deleteTexture(st.composed.tex); }
    if (st.pub) { gl.deleteFramebuffer(st.pub.fb); gl.deleteTexture(st.pub.tex); st.pub = null; }
    st.pubSeq = -1;
    st.decal = [fxPaintUpload(surface), null];
    if (!st.decal[0]) return false;
    st.decal[1] = fxPaintBuffer(w, h);
    if (!st.decal[1]) return false;
    st.cur = 0;
    // base：临时停用这枚 decal 再折。fxResolved 是同步调用，停用期间没有别的读者。
    const was = rec.enabled;
    rec.enabled = false;
    let baseCv = null;
    try { baseCv = fxResolved(l); } finally { rec.enabled = was; }
    if (!baseCv) return false;
    st.base = fxPaintUpload(baseCv);
    if (!st.base) return false;
    st.composed = fxPaintBuffer(w, h);
    if (!st.composed) return false;
    st.key = fxPaintLayerKey(l);
    st.seq = 0;
    if (!fxPaintCompose(st)) return false;
    st.live = true;
    fxgl.stats.paintBegin++;
    return true;
}

// 预览的一帧：ink 已经是「要盖上去的那张墨」（上色/Alpha/选区都在调用方烘好）。
// 它只改 decal 纹理，随后重合成 composed —— 2D 面仍然原样。
function fxPaintInk(l, ink, erase) {
    const gl = fxglInit();
    const st = fxPaintCache.get(l);
    if (!gl || !st || !st.live || !ink) return false;
    const n = nativeSize(ink);
    if (n.w !== st.w || n.h !== st.h) return false;    // 入口保证同一网格
    if (!st.ink) {
        st.ink = fxPaintBuffer(st.w, st.h);
        if (!st.ink) return false;
    }
    fxglUploadCanvas(st.ink.tex, ink);
    const dst = st.decal[st.cur], out = st.decal[1 - st.cur];
    fxglRunPass(out, fxgl.progs.ink, p => {
        fxglBindTex(p, 'uDst', dst.tex, 0);
        fxglBindTex(p, 'uSrc', st.ink.tex, 1);
        gl.uniform1i(fxglU(p, 'uMode'), erase ? 1 : 0);
    }, { w: st.w, h: st.h });
    st.cur = 1 - st.cur;
    st.seq++;
    if (!fxPaintCompose(st)) return false;
    fxgl.stats.paintInk++;
    return true;
}

// 合成器问「这一层有没有一笔正在纹理里」。没有就照旧折 2D 面。
// 合成器的 tex 入口按**预乘**解释（与 applyLayerEffectsTexture 的 present 出口一致），所以这里
// 懒一次 present：straight 的 composed → 预乘的 pub。编辑器的 fxPaintPresent 仍走 composed，
// 不会二次预乘。
function fxPaintTexture(l) {
    const st = fxPaintCache.get(l);
    if (!st || !st.live) return null;
    if (!st.pub) {
        st.pub = fxPaintBuffer(st.w, st.h);
        if (!st.pub) return null;
        st.pubSeq = -1;
    }
    if (st.pubSeq !== st.seq) {
        fxglRunPass(st.pub, fxgl.progs.present, p => fxglBindTex(p, 'uTex', st.composed.tex, 0),
                    { w: st.w, h: st.h });
        st.pubSeq = st.seq;
    }
    return { gl: fxgl.gl, tex: st.pub.tex, w: st.w, h: st.h, seq: st.seq };
}

// 显示用：把 composed 呈成一张**2D 画布**（预乘出口，与链的 present 同一条），调用方拿到后按图层
// 矩阵 drawImage。单上下文之后不能画进默认帧缓冲（那是显示面），所以渲进临时面再抄进一块专用画布。
// 这里不改 fxgl.w/h —— 链条的离屏池不参与。
let fxPaintCanvas = null;
function fxPaintPresent(l) {
    const st = fxPaintCache.get(l);
    if (!st || !st.live) return null;
    const out = fxglOutFace(st.w, st.h);
    if (!out) return null;
    fxglRunPass(out, fxgl.progs.present, p => fxglBindTex(p, 'uTex', st.composed.tex, 0),
                { w: st.w, h: st.h });
    const img = fxglReadFace(out, st.w, st.h);
    if (!img) return null;
    if (!fxPaintCanvas) fxPaintCanvas = document.createElement('canvas');
    if (fxPaintCanvas.width !== st.w) fxPaintCanvas.width = st.w;
    if (fxPaintCanvas.height !== st.h) fxPaintCanvas.height = st.h;
    const g = fxPaintCanvas.getContext('2d');
    resetCtx(g);
    g.clearRect(0, 0, st.w, st.h);
    g.putImageData(img, 0, 0);
    fxgl.stats.paintPresent++;
    return fxPaintCanvas;
}

// 提交：2D 面已经由调用方写好，纹理从此刻起不再代表这一层（下一次 begin 会按新面重传）。
function fxPaintEnd(l) {
    const st = fxPaintCache.get(l);
    if (!st) return;
    st.live = false;
    st.key = '';
    st.seq = 0;
    st.pubSeq = -1;
}

// ---- 后端分界 (the split) ----
// 链只有 WebGL 跑得动,所以「前端烘到哪、后端重放从哪起」这条线只能落在**最后一条启用的链**上:
// 它左边 (含) 由前端折成一张结算面,它右边的 decal 与蒙版按序交给 Python 重放。默认那条
// `Decal·Effects·Mask` 于是与这个功能出现之前逐像素相同 —— 贴片和链烘进 src,蒙版仍原样送出。
// 折不出新面时 surface 就是 l.img 本身,调用方据此决定能不能走 l.src 那条免重编码的快路。
//
// **Stash 也把这条线往右推。** 它的面是"这一层以下那一叠",只有合成器现场才有 —— Python 那一侧
// 收到一枚 `surface: None` 的面只会跳过它,于是快照在导出里凭空消失。所以分界线落在
// `max(最后一条链, 最后一枚 Stash)`:那之前(含它)由前端折进结算面,后端只重放它右边那些。
function backendCutIndex(l, recs) {
    let i = lastChainIndex(l, recs);
    for (let k = recs.length - 1; k >= 0; k--) {
        const r = recs[k];
        if (!r || r.type !== 'stash' || !attrEnabled(r)) continue;
        // 面还没抄出来(这一帧没有累积账):它什么都不出,把它也算进分界线只会白折一趟。
        if (r.surface && r.surface.width && r.surface.height) i = Math.max(i, k);
        break;
    }
    return i;
}

function fxSplitForBackend(l) {
    return fxMirrorHidden(l, () => {
    syncGeneratorFaces(l);
    const recs = attrRecordsOf(l);
    const thru = backendCutIndex(l, recs);
    if (thru < 0) return { surface: l.img, rest: recs };
    const { w, h } = layerGridOf(l);
    const surface = fxScratch(w, h);
    if (!fxDropStrip(l, surface, null, thru, FX_CUT_ALL)) return { surface: l.img, rest: recs };
    return { surface, rest: recs.slice(thru + 1) };
    });
}

// Generate 那张图:整条折完,但**留给后端的那几枚蒙版不裁**。蒙版是覆盖率而不是剪刀时,后端还要乘
// 一次;递一张已经裁过的图过去等于乘两次,而且模型会看见一个自己没挖的洞。
// `base` **换掉底位那一枚的面** —— 空白图层送出去的是噪声,链得跑在噪声上而不是跑在空的 img 上。
// 没有任何 attribute 做事时返回 null:调用方宁可发原始 l.src,也别白白重编码一张同图。
function fxSurfaceForGenerate(l, base) {
    if (!l) return null;
    return fxMirrorHidden(l, () => {
    syncGeneratorFaces(l);
    const recs = attrRecordsOf(l);
    const thru = lastChainIndex(l, recs);
    const cut = (r, i) => r.type !== 'mask' || i <= thru;
    // 一张图都没有的层(Stash 那一类)没有底位可问,格子走 `layerGridOf`。
    const { w, h } = base ? nativeSize(base) : layerGridOf(l);
    if (!w || !h) return null;
    const surface = fxScratch(w, h);
    if (!fxDropStrip(l, surface, base || null, -1, cut)) return null;
    return surface;
    });
}

// 后端那一次乘法该乘的是哪些蒙版:最后一条启用链**右边**的那些,全与起来。一条都不剩 = 前端已经
// 裁进结算面了,后端乘全白 (调用方那侧的合成全白就是这个意思)。
// 这里不按网格尺寸筛:蒙版本来就是按各自尺寸发过去、由后端 resample 的,筛掉会把一张画歪的蒙版
// 变成「没有蒙版」。
// 分界线与 `fxSplitForBackend` **必须是同一根**(`backendCutIndex`),否则一枚蒙版会在前端被裁一次、
// 后端再乘一次 —— 那种"画面边缘忽然淡掉"的怪相就是这条不一致。
function fxDistributedMask(l, w, h) {
    const recs = attrRecordsOf(l);
    const thru = backendCutIndex(l, recs);
    const list = [];
    for (let i = thru + 1; i < recs.length; i++) {
        const s = recs[i].type === 'mask' ? recs[i].surface : null;
        if (s && s.width && s.height) list.push(s);
    }
    if (!list.length) return null;
    return list.length === 1 ? list[0] : fxAndInto(list, w, h);
}
